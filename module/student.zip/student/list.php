<?php
/* Dropdown data for the Reserve Slot modal. $mydb is set up by
   include/initialize.php, which template.php has already loaded.

   NOTE: there is no Section field here on purpose. Sectioning is the
   SECOND stage and happens on the Enrollment screen. */
global $mydb;

$regSchoolYears = array();
$mydb->setQuery("SELECT SY_ID, SCHOOL_YEAR, STATUS FROM `tblschoolyear` ORDER BY SCHOOL_YEAR DESC");
foreach ($mydb->loadResultList() as $r) { $regSchoolYears[] = $r; }

$regCourses = array();
$mydb->setQuery("SELECT COURSE_ID, COURSE_CODE, COURSE_NAME FROM `tblcourses` WHERE STATUS = 'Active' ORDER BY COURSE_CODE ASC");
foreach ($mydb->loadResultList() as $r) { $regCourses[] = $r; }

$regYearLevels = array('1st Year', '2nd Year', '3rd Year', '4th Year');
$regSemesters  = array('1st Semester', '2nd Semester', 'Summer');
$regCategories = array('New', 'Old', 'Transferee', 'Returnee', 'Shiftee');
?>
 <section class="content">
      <div class="container-fluid">
         <?php check_message(); ?>
        <div class="row">
          <div class="col-12">
          
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List of Students</h3>
              </div>

              <!-- /.card-header -->
              <div class="card-body">
                <table id="tblstudent" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <!-- /`LNAME`, `FNAME`, `MNAME`, `SEX`, `BDAY`-->
                    <th>LNAME</th>
                    <th>FNAME</th>
                    <th>MNAME</th>
                    <th>SEX</th>
                      <th>BDAY</th>

                   
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  
                  </tbody>
                  <tfoot>
                  
                  </tfoot>
                </table>
                  <div class="btn-group">
          
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#AddNewEntry">Add New</button>
                 
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


<div class="modal fade" id="AddNewEntry">
        <div class="modal-dialog modal-lg">
        <form action="controller.php?action=add" enctype="multipart/form-data" method="POST">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add New Student</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                         
              <!-- /.card-header -->
              <div class="row">
                    
                    <!-- Photo upload, top and centered above the rest of the
                         form - shared across both tabs, so it stays outside
                         them rather than living in either one. Optional: a
                         student can be added without one, and shows this
                         same grey silhouette on the View page until a photo
                         is attached. -->
                    <div class="col-12 text-center mb-3">
                      <div class="form-group mb-0">
                        <img id="photoPreview" src="<?php echo WEB_ROOT; ?>module/student/image/default.png"
                             alt="Student photo"
                             style="width:110px; height:110px; object-fit:cover; border-radius:50%; border:3px solid #dee2e6;">
                        <div class="mt-2 d-flex justify-content-center">
                          <input type="file" class="form-control-file" style="max-width:230px;"
                                 name="PHOTO" id="PHOTO" accept="image/jpeg,image/png">
                        </div>
                        <small class="text-muted d-block mt-1">JPG or PNG, up to 3MB.</small>
                      </div>
                    </div>

                  </div>

                  <!-- Same Profile Info / Contact Info split as the View
                       page, so entering a student mirrors how their record
                       is later displayed. -->
                  <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a class="nav-link active" href="#profileAdd" data-toggle="tab">Profile Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contactAdd" data-toggle="tab">Contact Info</a></li>
                  </ul>

                  <div class="tab-content">

                    <div class="tab-pane active" id="profileAdd">
                      <div class="row">

 <!-- /.container-fluid //`IDNO`, `FNAME`, `LNAME`, `MNAME`, `SEX`, `BDAY` -->

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="IDNO"  class="col-form-label col-form-label-sm">Student ID Number</label>
                        <input type="text" class="form-control form-control-sm" name="IDNO"
                        id="IDNO" placeholder="Enter Student ID Number" required>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="FNAME"  class="col-form-label col-form-label-sm">First Name</label>
                        <input type="text" class="form-control form-control-sm" name="FNAME"
                        id="FNAME" placeholder="Enter First Name" required>
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="MNAME"  class="col-form-label col-form-label-sm">Middle Name</label>
                        <input type="text" class="form-control form-control-sm" name="MNAME"
                        id="MNAME" placeholder="Enter Middle Name" required>
                      </div>
                    </div>
                   
  <div class="col-sm-6">
                      <div class="form-group">
                       <label for="LNAME"  class="col-form-label col-form-label-sm">Last Name</label>
                        <input type="text" class="form-control form-control-sm" name="LNAME"
                        id="LNAME" placeholder="Enter Last Name" required>
                      </div>
                    </div>


  <div class="col-sm-6">
                      <div class="form-group">
                       <label for="SEX"  class="col-form-label col-form-label-sm">Select Gender</label>
                         <select class="form-control form-control-sm" name="SEX" id="SEX" required>
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                         
                        </select> 
                      </div>
                    </div>



                     <div class="col-sm-6">


                      <div class="form-group">
                       <label for="BDAY"  class="col-form-label col-form-label-sm">Date Started</label>
                       
                        <input type="date" class="form-control form-control-sm" name="BDAY"
                        id="BDAY" placeholder="Enter Birth of Date" required>
                      </div>
                    </div>

                    <!-- Additional profile fields, so what shows on the View
                         page's Profile Info tab can actually be captured
                         here instead of only being editable through
                         phpMyAdmin. All optional - a student record should
                         not be blocked on details that may not be
                         available yet. -->
                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="BPLACE"  class="col-form-label col-form-label-sm">Birth Place</label>
                        <input type="text" class="form-control form-control-sm" name="BPLACE"
                        id="BPLACE" placeholder="Enter Birth Place">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="NATIONALITY"  class="col-form-label col-form-label-sm">Nationality</label>
                        <input type="text" class="form-control form-control-sm" name="NATIONALITY"
                        id="NATIONALITY" placeholder="Enter Nationality">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="RELIGION"  class="col-form-label col-form-label-sm">Religion</label>
                        <input type="text" class="form-control form-control-sm" name="RELIGION"
                        id="RELIGION" placeholder="Enter Religion">
                      </div>
                    </div>

                      </div>
                    </div>
                    <!-- /#profileAdd -->

                    <div class="tab-pane" id="contactAdd">
                      <div class="row">

                    <!-- Contact-only fields, matching the View page's
                         Contact Info tab. -->
                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="CONTACT_NO"  class="col-form-label col-form-label-sm">Contact Number</label>
                        <input type="text" class="form-control form-control-sm" name="CONTACT_NO"
                        id="CONTACT_NO" placeholder="Enter Contact Number">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="EMAIL"  class="col-form-label col-form-label-sm">Email</label>
                        <input type="email" class="form-control form-control-sm" name="EMAIL"
                        id="EMAIL" placeholder="Enter Email">
                      </div>
                    </div>

                    <div class="col-sm-12">
                      <div class="form-group">
                       <label for="HOME_ADD"  class="col-form-label col-form-label-sm">Home Address</label>
                        <textarea class="form-control form-control-sm" name="HOME_ADD"
                        id="HOME_ADD" placeholder="Enter Home Address" rows="2"></textarea>
                      </div>
                    </div>

                      </div>
                    </div>
                    <!-- /#contactAdd -->

                  </div>
                  <!-- /.tab-content -->
                                
                <!-- /.card-body -->
           
              <!-- /.card-body -->
           
            </div>
            <div class="modal-footer justify-content-between">
             <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 <button type="submit" class="btn btn-primary" name="save">Save changes</button>
             
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
<!-----END of Add Form---->

<script type="text/javascript">
/* Shows a quick local preview of the chosen photo before the form is even
   submitted, right in the circular frame above Student ID Number.
   Purely visual - the file itself is only actually read when the form
   posts. Cancelling the file picker reverts back to the grey silhouette. */
document.addEventListener('DOMContentLoaded', function () {
  var input = document.getElementById('PHOTO');
  var preview = document.getElementById('photoPreview');
  var defaultSrc = preview ? preview.getAttribute('src') : '';
  if (input && preview) {
    input.addEventListener('change', function (e) {
      var file = e.target.files && e.target.files[0];
      preview.src = file ? URL.createObjectURL(file) : defaultSrc;
    });
  }

  /* Same live-preview behaviour for the Edit modal's photo picker. Its
     "default" src gets set to the student's actual current photo by the
     editEntry click handler in index.php before this preview ever runs,
     so cancelling the file picker here reverts to THAT photo, not the
     grey silhouette. */
  var input1 = document.getElementById('PHOTO1');
  var preview1 = document.getElementById('photoPreview1');
  if (input1 && preview1) {
    input1.addEventListener('change', function (e) {
      var file = e.target.files && e.target.files[0];
      preview1.src = file ? URL.createObjectURL(file) : preview1.getAttribute('data-current-src');
    });
  }
});
</script>


   <div class="modal fade" id="editEntry">
        <div class="modal-dialog modal-lg">
        <form action="controller.php?action=edit" enctype="multipart/form-data" method="POST">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Edit Student</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                         
              <!-- /.card-header -->
              <div class="row">
                    
 <!-- /.container-fluid //`IDNO`, `FNAME`, `LNAME`, `MNAME`, `SEX`, `BDAY` -->

<!-- carries S_ID of the row being edited. Hidden: it is not something
     the user should ever see or type into. -->
<input type="hidden" name="UID" id="UID" value="">

                    <!-- Photo replace: optional. Leaving this blank keeps
                         the student's current photo - controller.php only
                         touches PHOTO when a new file is actually chosen.
                         Shared across both tabs, so it stays outside them. -->
                    <div class="col-12 text-center mb-3">
                      <div class="form-group mb-0">
                        <img id="photoPreview1" src="<?php echo WEB_ROOT; ?>module/student/image/default.png"
                             alt="Student photo"
                             style="width:110px; height:110px; object-fit:cover; border-radius:50%; border:3px solid #dee2e6;">
                        <div class="mt-2 d-flex justify-content-center">
                          <input type="file" class="form-control-file" style="max-width:230px;"
                                 name="PHOTO1" id="PHOTO1" accept="image/jpeg,image/png">
                        </div>
                        <small class="text-muted d-block mt-1">Leave blank to keep the current photo. JPG or PNG, up to 3MB.</small>
                      </div>
                    </div>

                  </div>

                  <!-- Same Profile Info / Contact Info split as the View
                       page, so editing a student mirrors how their record
                       is later displayed. -->
                  <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a class="nav-link active" href="#profileEdit" data-toggle="tab">Profile Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contactEdit" data-toggle="tab">Contact Info</a></li>
                  </ul>

                  <div class="tab-content">

                    <div class="tab-pane active" id="profileEdit">
                      <div class="row">

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="IDNO1"  class="col-form-label col-form-label-sm">Student ID Number</label>
                        <input type="text" class="form-control form-control-sm" name="IDNO1"
                        id="IDNO1" placeholder="Enter Student ID Number" required>
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="FNAME1"  class="col-form-label col-form-label-sm">First Name</label>
                        <input type="text" class="form-control form-control-sm" name="FNAME1"
                        id="FNAME1" placeholder="Enter First Name" required>
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="MNAME1"  class="col-form-label col-form-label-sm">Middle Name</label>
                        <input type="text" class="form-control form-control-sm" name="MNAME1"
                        id="MNAME1" placeholder="Enter Middle Name" required>
                      </div>
                    </div>
                   
  <div class="col-sm-6">
                      <div class="form-group">
                       <label for="LNAME1"  class="col-form-label col-form-label-sm">Last Name</label>
                        <input type="text" class="form-control form-control-sm" name="LNAME1"
                        id="LNAME1" placeholder="Enter Last Name" required>
                      </div>
                    </div>


  <div class="col-sm-6">
                      <div class="form-group">
                       <label for="SEX1"  class="col-form-label col-form-label-sm">Select Gender</label>
                         <select class="form-control form-control-sm" name="SEX1" id="SEX1" required>
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                         
                        </select> 
                      </div>
                    </div>



                     <div class="col-sm-6">


                      <div class="form-group">
                       <label for="BDAY1"  class="col-form-label col-form-label-sm">Date Started</label>
                       
                        <input type="date" class="form-control form-control-sm" name="BDAY1"
                        id="BDAY1" placeholder="Enter Birth of Date" required>
                      </div>
                    </div>

                    <!-- Same additional fields as Add New, so editing a
                         student can actually fill in what the View page
                         shows instead of that only being possible through
                         phpMyAdmin. -->
                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="BPLACE1"  class="col-form-label col-form-label-sm">Birth Place</label>
                        <input type="text" class="form-control form-control-sm" name="BPLACE1"
                        id="BPLACE1" placeholder="Enter Birth Place">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="NATIONALITY1"  class="col-form-label col-form-label-sm">Nationality</label>
                        <input type="text" class="form-control form-control-sm" name="NATIONALITY1"
                        id="NATIONALITY1" placeholder="Enter Nationality">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="RELIGION1"  class="col-form-label col-form-label-sm">Religion</label>
                        <input type="text" class="form-control form-control-sm" name="RELIGION1"
                        id="RELIGION1" placeholder="Enter Religion">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="STATUS1"  class="col-form-label col-form-label-sm">Status</label>
                         <select class="form-control form-control-sm" name="STATUS1" id="STATUS1">
                          <option value="Active">Active</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>

                      </div>
                    </div>
                    <!-- /#profileEdit -->

                    <div class="tab-pane" id="contactEdit">
                      <div class="row">

                    <!-- Contact-only fields, matching the View page's
                         Contact Info tab. -->
                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="CONTACT_NO1"  class="col-form-label col-form-label-sm">Contact Number</label>
                        <input type="text" class="form-control form-control-sm" name="CONTACT_NO1"
                        id="CONTACT_NO1" placeholder="Enter Contact Number">
                      </div>
                    </div>

                    <div class="col-sm-6">
                      <div class="form-group">
                       <label for="EMAIL1"  class="col-form-label col-form-label-sm">Email</label>
                        <input type="email" class="form-control form-control-sm" name="EMAIL1"
                        id="EMAIL1" placeholder="Enter Email">
                      </div>
                    </div>

                    <div class="col-sm-12">
                      <div class="form-group">
                       <label for="HOME_ADD1"  class="col-form-label col-form-label-sm">Home Address</label>
                        <textarea class="form-control form-control-sm" name="HOME_ADD1"
                        id="HOME_ADD1" placeholder="Enter Home Address" rows="2"></textarea>
                      </div>
                    </div>

                      </div>
                    </div>
                    <!-- /#contactEdit -->

                  </div>
                  <!-- /.tab-content -->
                                
                <!-- /.card-body -->
           
              <!-- /.card-body -->
           
            </div>
            <div class="modal-footer justify-content-between">
             <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 <button type="submit" class="btn btn-primary" name="edit">Save changes</button>
             
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
<!-----END of Edit Form---->


<!-----STAGE 1: RESERVE SLOT---->
<!--
     Opened by the green Reg button in the Action column.

     This creates the enrollment record with STATUS = Reserved. It does
     NOT assign a section and does NOT set the enrollment date, because
     at this point in the flow neither is known yet. Both are filled in
     later from the Enrollment screen (Sectioning).
-->
   <div class="modal fade" id="registerEntry">
        <div class="modal-dialog">
        <form action="controller.php?action=register" method="POST">
          <div class="modal-content">
            <div class="modal-header bg-success">
              <h4 class="modal-title"><i class="fa fa-clipboard-check"></i> &nbsp;Reserve Enrollment Slot</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

              <input type="hidden" name="R_SID" id="R_SID" value="">

              <!-- Who is being reserved. Read only: the student comes from
                   whichever row's button was clicked, not from typing. -->
              <div class="callout callout-info py-2 mb-3">
                <div class="row">
                  <div class="col-sm-5">
                    <small class="text-muted d-block">ID No.</small>
                    <strong id="R_IDNO_TEXT">-</strong>
                  </div>
                  <div class="col-sm-7">
                    <small class="text-muted d-block">Student Name</small>
                    <strong id="R_NAME_TEXT">-</strong>
                  </div>
                </div>
              </div>

              <div class="row">

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_SY" class="col-form-label col-form-label-sm">Academic Year</label>
                    <select class="form-control form-control-sm" name="R_SY" id="R_SY" required>
                      <option value="">Select Academic Year</option>
                      <?php foreach ($regSchoolYears as $sy) { ?>
                      <option value="<?php echo $sy->SY_ID; ?>"><?php echo htmlspecialchars($sy->SCHOOL_YEAR); ?><?php echo ($sy->STATUS == 'Active') ? ' (Active)' : ''; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_SEMESTER" class="col-form-label col-form-label-sm">Semester</label>
                    <select class="form-control form-control-sm" name="R_SEMESTER" id="R_SEMESTER" required>
                      <option value="">Select Semester</option>
                      <?php foreach ($regSemesters as $sem) { ?>
                      <option value="<?php echo $sem; ?>"><?php echo $sem; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="col-sm-12">
                  <div class="form-group">
                    <label for="R_COURSE" class="col-form-label col-form-label-sm">Course</label>
                    <select class="form-control form-control-sm" name="R_COURSE" id="R_COURSE" required>
                      <option value="">Select Course</option>
                      <?php foreach ($regCourses as $c) { ?>
                      <option value="<?php echo $c->COURSE_ID; ?>"><?php echo htmlspecialchars($c->COURSE_CODE.' - '.$c->COURSE_NAME); ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_YEARLEVEL" class="col-form-label col-form-label-sm">Year Level</label>
                    <select class="form-control form-control-sm" name="R_YEARLEVEL" id="R_YEARLEVEL" required>
                      <option value="">Select Year Level</option>
                      <?php foreach ($regYearLevels as $yl) { ?>
                      <option value="<?php echo $yl; ?>"><?php echo $yl; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_CURRICULUM" class="col-form-label col-form-label-sm">Curriculum Yr</label>
                    <input type="text" class="form-control form-control-sm" name="R_CURRICULUM"
                           id="R_CURRICULUM" placeholder="e.g. 2023-2024">
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_CATEGORY" class="col-form-label col-form-label-sm">Category</label>
                    <select class="form-control form-control-sm" name="R_CATEGORY" id="R_CATEGORY" required>
                      <?php foreach ($regCategories as $cat) { ?>
                      <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="R_DATE_RESERVED" class="col-form-label col-form-label-sm">Date Reserved</label>
                    <input type="date" class="form-control form-control-sm" name="R_DATE_RESERVED"
                           id="R_DATE_RESERVED" value="<?php echo date('Y-m-d'); ?>" required>
                  </div>
                </div>

              </div>

              <div class="callout callout-warning py-2 mb-0">
                <small>
                  Section and Date Enrolled are assigned later, from
                  <strong>Enrollment &gt; Sectioning</strong>. This step only
                  reserves the slot.
                </small>
              </div>

            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-success" name="register"><i class="fa fa-save"></i> Reserve</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
<!-----END of Reserve Form---->




<?php


?>